# manCULTA 0.9.5

## Docker Hub Tag

* ijapesigan/manculta:2025-07-28-16482016

## Code Changes

* Changes in summary functions.

# manCULTA 0.9.4

## Docker Hub Tag

* ijapesigan/manculta:2025-07-27-20321701

## Code Changes

* Change in `params`.

# manCULTA 0.9.3

## Docker Hub Tag

* ijapesigan/manculta:2025-07-22-21481116

## Code Changes

* Added summary functions.

# manCULTA 0.9.2

## Docker Hub Tag

* ijapesigan/manculta:2025-07-13-16280506

## Code Changes

* Added functions to generate data from a 2-profile CULTA model.
* Added functions to fit the following models:
  - 2-profile CULTA model
  - 2-profile LTA model
  - 2-profile RILTA model
  - 1-profile CULTA model
* Added simulation functions.

# manCULTA 0.9.1

* Initial setup
